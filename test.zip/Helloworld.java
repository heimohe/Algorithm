package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.txw2.Document;

import cn.dsna.util.images.ValidateCode;

public class Helloworld extends HttpServlet {

	public Helloworld() {
		super();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//���߿ͻ��˲�ʹ�û���
		response.setHeader("pragma", "no-cache");
		response.setHeader("cache-control", "no-cache");
		response.setIntHeader("expires", 0);
		
		ValidateCode vc = new ValidateCode(110, 25, 4, 9);
		String code = vc.getCode();//�õ����ɵ��ַ�
		System.out.println("�õ����ɵ��ַ�Ϊ"+code);
		
		//Ϊ�˸�judgeҳ�洫ֵ
		request.getSession().setAttribute("validatecode", code);
		
		String code1 = request.getParameter("code");
		System.out.println("helloworld�����codeΪ"+code1);
		vc.write(response.getOutputStream());
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
