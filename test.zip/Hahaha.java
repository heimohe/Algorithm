package com.test;

public class Hahaha {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(test());
	}

	public static boolean test() {
		if(true)
		{
			System.out.println("rs.next()Ϊtrue������true");
			return true;
		}else{
			System.out.println("rs.next()Ϊfalse������false");
			return false;
		}
	}

}
