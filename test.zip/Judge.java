package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Judge extends HttpServlet {


	public Judge() {
		super();
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String code = request.getParameter("code");
		String code1 = (String)request.getSession().getAttribute("validatecode");
		System.out.println("judge�������֤��Ϊ"+code);
		System.out.println("��helloworld servlet������ֵΪ"+code1);
		if(code1.equals(code))
		{
			System.out.println("��֤�ɹ�");
		}

	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
